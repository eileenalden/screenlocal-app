# ScreenLocal Emergency Deployment

## Quick Deploy Options:

### Option 1: Vercel (Fastest)
1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel --prod`
3. Set environment variables in Vercel dashboard
4. Domain will be available immediately

### Option 2: Netlify
1. Install Netlify CLI: `npm i -g netlify-cli`
2. Run: `netlify deploy --prod`
3. Configure domain in Netlify dashboard

### Option 3: Railway
1. Connect GitHub repo to Railway
2. Deploy automatically with domain support

## Environment Variables Needed:
- DATABASE_URL
- OPENAI_API_KEY
- SESSION_SECRET

## Build Commands:
- Build: `npm run build`
- Start: `npm start`
